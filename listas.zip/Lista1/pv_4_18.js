




beBetter = () => {
    while(alive == true){
        eat(); 
        sleep();
        _try(); 
        repeat(); 
    }
}

























